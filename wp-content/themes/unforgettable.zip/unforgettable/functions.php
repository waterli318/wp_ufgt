<?php 
	function theme_styles() {
		wp_enqueue_style( 'bootstrap_css', get_template_directory_uri() . '/css/bootstrap.css' );
		wp_enqueue_style( 'main_css', get_template_directory_uri() . '/style.css' );
	}

	add_action( 'wp_enqueue_scripts', 'theme_styles');

	function theme_js() {
		wp_enqueue_script( 'bootstrap_js', get_template_directory_uri() . '/js/bootstrap.min.js');
	}

	add_action( 'wp_enqueue_scripts', 'theme_js');

	function add_id_in_profile($user) { 
		echo "
		<table class='form-table'>

		<tr>
			<th><label for='id'>ID</label></th>

			<td>
				<input type='text' name='id' id='id' value='<?php echo esc_attr( get_the_author_meta( 'id', $user->ID ) ); ?>' class='regular-text' /><br />
				<span class='description'>Please enter your user id.</span>
			</td>
		</tr>

		</table>
		";
	}
	add_action('show_user_profile','add_id_in_profile');
	add_action('edit_user_profile','add_id_in_profile');
?>

<!-- restrict the content length -->
<?php   
  add_filter("the_content", "plugin_myContentFilter");

  function plugin_myContentFilter($content)
  {
    // Take the existing content and return a subset of it
    return substr($content, 0, 300);
  }
?>

<?php
/**
 * Register our sidebars and widgetized areas.
 *
 */
function arphabet_widgets_init() {

	register_sidebar( array(
		'name'          => 'Home right sidebar',
		'id'            => 'home_right_1',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="rounded">',
		'after_title'   => '</h2>',
	) );

}
add_action( 'widgets_init', 'arphabet_widgets_init' );
?>

<!-- Set cookie expriation time -->
<?php 
add_filter('auth_cookie_expiration', 'my_expiration_filter', 99, 3);
function my_expiration_filter($seconds, $user_id, $remember){

    //if "remember me" is checked;
    if ( $remember ) {
        //WP defaults to 1 week;
        $expiration = 7*24*60*60; //UPDATE HERE;
    } else {
        //WP defaults to 24 hour;
        $expiration = 24*60*60; //UPDATE HERE;
    }

    //http://en.wikipedia.org/wiki/Year_2038_problem
    if ( PHP_INT_MAX - time() < $expiration ) {
        //Fix to a little bit earlier!
        $expiration =  PHP_INT_MAX - time() - 5;
    }

    return $expiration;
}
?>