<div id="footer">
	Copyright © 2007 <?php bloginfo(’name’); ?>
</div>